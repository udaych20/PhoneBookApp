import { Component, OnInit, Output,EventEmitter } from '@angular/core';


@Component({
  selector: 'app-ceb',
  templateUrl: './ceb.component.html',
  styles: []
})
export class CebComponent implements OnInit {

  @Output()  findLastVisit= new EventEmitter<String>();


  constructor() { }

  ngOnInit() {
   
  }

  btClick(){
    this.findLastVisit.emit("uday");
  }

}
