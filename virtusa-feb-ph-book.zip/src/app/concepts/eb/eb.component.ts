import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eb',
  templateUrl: './eb.component.html',
  styleUrls: []
})
export class EbComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  alertMsg(e){
    console.log(e);
    alert('Hi');
  }

}
