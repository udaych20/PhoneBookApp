import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-si',
  templateUrl: './si.component.html',
  styleUrls: []
})
export class SiComponent implements OnInit {
  featurename:string = "abc";
  exp: number = 10;

  isLoggingIn: Boolean = false;
  skills: string[] = ['java', '.net', 'angular'];

  names: Object = {
    name: 'abc', city: 'xyz'
  }



  constructor() { }

  
  add(x: number, y: number): number {
    return x + y;
  }
  ngOnInit() {
  }

}
