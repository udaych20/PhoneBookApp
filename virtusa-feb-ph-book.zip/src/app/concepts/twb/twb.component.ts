import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-twb',
  templateUrl: './twb.component.html',
  styleUrls: []
})
export class TwbComponent implements OnInit {

  //vName:string = "Uday";
  constructor() { }

  ngOnInit() {
  }

}
