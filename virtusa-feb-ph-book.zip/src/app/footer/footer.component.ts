import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  //  templateUrl: './footer.component.html',
  template: `  <footer class="text-center bg-light">
  <hr>
  <p>Contact Manager App built in Training in 2019</p>
  <p>Copyright &copy; 2019</p>
</footer>
`,
  styles: []
})
export class FooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
