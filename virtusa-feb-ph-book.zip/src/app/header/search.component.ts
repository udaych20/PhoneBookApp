import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search',
  template: `
   
  `,
  styles: []
})
export class SearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  

}
